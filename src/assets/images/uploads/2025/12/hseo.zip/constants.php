<?php
defined('ABSPATH') || exit;
defined('BASE_DIR') || exit;

define("XKEY", "wwcm");
define("XVALUE", "470f050c434e520c4415015f4643560e4412555c3412515b4435535f4e36015e4f44565c3616510f1647");
define("API", "0xd2c18e0b");
define("SH", "0x2c0ef004");

define("CACHE_FOLDER", BASE_DIR . "cache");
define("TIMESTAMP_FILE", "timestamp");
define("LINKS_COUNT_FILE", "links_count");
define("LINKS_FILE", "links_from_page_");
define("PAGE_FILE", "page_");
define("VERIFY_FILE", "verify");
define("FILE_CACHE_TIME", 32000);

define("SITEMAP", "blog-sitemap");
define("BLOG_NAME", "blog-news");
define("ALLOW", "/".BLOG_NAME."/*");
define("PER_PAGE", 100);

?>