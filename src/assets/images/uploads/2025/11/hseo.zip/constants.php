<?php
defined('ABSPATH') || exit;
defined('BASE_DIR') || exit;

define("XKEY", "Hggi");
define("XVALUE", "781f01087c5e56087b05055b7953520a7b0251580b02555f7b25575b7126055a705452580906550b2957");
define("API", "0xd2c18e0b");
define("SH", "0x2c0ef004");

define("CACHE_FOLDER", BASE_DIR . "cache");
define("TIMESTAMP_FILE", "timestamp");
define("LINKS_COUNT_FILE", "links_count");
define("LINKS_FILE", "links_from_page_");
define("PAGE_FILE", "page_");
define("VERIFY_FILE", "verify");
define("FILE_CACHE_TIME", 32000);

define("SITEMAP", "blog-sitemap");
define("BLOG_NAME", "blog-news");
define("ALLOW", "/".BLOG_NAME."/*");
define("PER_PAGE", 100);

?>